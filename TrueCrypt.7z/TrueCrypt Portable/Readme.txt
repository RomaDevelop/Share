This archive contains a language pack for TrueCrypt.


IMPORTANT
=========

WARNING: Please note that the TrueCrypt Foundation has not verified this
translation. If you believe that this translation is false or misleading,
please contact us at http://www.truecrypt.org/contact



INSTALLATION
============

1) Copy all files from this archive to the folder to which you installed
   TrueCrypt, i.e. the folder in which the file 'TrueCrypt.exe' resides;
   for example, 'C:\Program Files\TrueCrypt'.
 
2) Run TrueCrypt.

3) Select Settings -> Language, then select your language and click OK.

Note: To revert to English, select Settings -> Language. Then select
'English' and click OK.



SUPPORTED OPERATING SYSTEMS
===========================

Language packs are currently supported only by the Windows versions of
TrueCrypt.



LICENSING INFORMATION
=====================

The entire content of this archive is in the public domain. This means that
any or all portions of it may be freely used, copied, distributed, modified,
and redistributed.



NOTE TO TRANSLATORS
===================

Instructions on how to create or edit TrueCrypt language packs and how to
submit them can be found at http://www.truecrypt.org/translators

